public class EmptyStackException extends RuntimeException {
}
