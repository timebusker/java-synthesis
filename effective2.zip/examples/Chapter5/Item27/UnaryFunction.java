// Unary function - page 131
public interface UnaryFunction<T> {
    T apply(T arg);
}
