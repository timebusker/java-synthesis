// Class hierarchy replacement for a tagged class
abstract class Figure {
    abstract double area();
}
