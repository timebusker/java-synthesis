// Service provider framework sketch - Service provider interface - Page 12

public interface Provider {
    Service newService();
}