public class EmptyStackException extends IllegalStateException {
}
