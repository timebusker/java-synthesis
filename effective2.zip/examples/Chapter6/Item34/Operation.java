// Emulated extensible enum using an interface - Page 165
public interface Operation {
    double apply(double x, double y);
}
